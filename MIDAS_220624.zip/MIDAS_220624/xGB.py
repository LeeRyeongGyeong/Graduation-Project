from xgboost import XGBClassifier
from sklearn.svm import SVC
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import interp
from itertools import cycle
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import seaborn as sns

# 웹페이지에서 검사 & 약물 입력 
def XGBoost_one(ACR_val,ISGG_I_val,ISL25P75P_I_val,POG30_val,RPGN2_val):
	df=pd.read_csv("powerranger_output_table.csv")
	final_df = df[['group','ACR','POG30','ISL25P75P_I','RPGN2','ISGG_I']] # 5가지 특징 데이터프레임에서 추출 
	feature_col=list(final_df.columns.difference(['group']))
	x=final_df[feature_col]
	y=final_df["group"]

    # 훈련데이터와 검증 데이터 8:2 로 나눔 
	x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42) 
	# XGBoost 모델 파라미터 지정 
	xgb_grid=XGBClassifier(n_estimators=300,max_depth=8,learning_rate=0.1)
	
	xgb_grid.fit(x_train,y_train) # 모델 
	y_pred= xgb_grid.predict(x_test)  
	pred1=accuracy_score(y_test, y_pred) # 성능 출력

	xgb_data = {'ACR':[float(ACR_val)],'ISGG_I':[float(ISGG_I_val)],'ISL25P75P_I':[float(ISL25P75P_I_val)],'POG30':[float(POG30_val)], 'RPGN2':[float(RPGN2_val)]}
	xgb_data_df = pd.DataFrame(xgb_data)

	#학습된 모델을 이용하여 웹페이지에서 입력받은 데이터로 질환 예측

	predict2 = xgb_grid.predict(xgb_data_df)

	return predict2

# 웹페이지에서 파일 업로드
def XGBoost_two_over(filename):
	df=pd.read_csv("powerranger_output_table.csv")
	final_df = df[['group','ACR','POG30','ISL25P75P_I','RPGN2','ISGG_I']] # 5가지 특징 데이터프레임에서 추출
	feature_col=list(final_df.columns.difference(['group']))
	x=final_df[feature_col]
	y=final_df["group"]

	# 훈련데이터와 검증 데이터 8:2 로 나눔 
	x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)
	
	# XGBoost 모델 파라미터 지정 
	xgb_grid=XGBClassifier(n_estimators=300,max_depth=8,learning_rate=0.1)
	xgb_grid.fit(x_train,y_train)
	y_pred= xgb_grid.predict(x_test) 
	pred1=accuracy_score(y_test, y_pred) # 성능 출력

	df = pd.read_csv("./uploads/"+filename,encoding='utf-8-sig') #  웹페이지에서 업로드 한 파일 가져오기 
	df = df[['ACR','POG30','ISL25P75P_I','RPGN2','ISGG_I']]
	#학습된 모델을 이용하여 웹페이지에서 입력받은 데이터로 질환 예측 
	predict2 = xgb_grid.predict(df)
	df["predict_group"]=predict2 # 데이터프레임에 레이블 추가 
	df.to_csv("static/predict_csv_file.csv",index=False) # 예측한 파일 서버에 저장 
	return df