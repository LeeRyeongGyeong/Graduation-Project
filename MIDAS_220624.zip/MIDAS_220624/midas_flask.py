from distutils.log import debug
import numpy as np
import psycopg2   #PostgreSQL 연동 어댑터/드라이버 
import pandas as pd
from flask import Flask,render_template,request
import os
from werkzeug.utils import secure_filename
from tkinter import *
from tkinter import messagebox
import matplotlib.pyplot as plt
from scipy import interp
from itertools import cycle
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import seaborn as sns
from xgboost import XGBClassifier
from xGB import XGBoost_one,XGBoost_two_over
############################ 데이터베이스 서버와 연결 ############################


app=Flask(__name__)

#-------------------------------------------------------------------------------------
# 웹페이지에서 검사와 약물 정보 받아와 모델로 예측한 것 웹페이지 연결  
@app.route('/analysis_one')
def analysis_one():
	ACR = request.args.get("ACR")

	IG = request.args.get("IG")
	IL = request.args.get("IL")
	Pioglitazone = request.args.get("Pioglitazone")
	Repaglinide = request.args.get("Repaglinide")
	if ACR=='' or IG =='' or IL =='' or Pioglitazone=='' or Repaglinide=='':
		tk=Tk()
		tk.wm_attributes("-topmost",1)
		tk.withdraw()
		messagebox.showerror("경고","검사, 약물 정보를 다시 한 번 확인하십시오.") 
		tk.destroy()
		return render_template('predict_page.html')
	result=XGBoost_one(ACR,IG,IL,Pioglitazone,Repaglinide)	
	if result==1:
		comment='당뇨병콩밭병증이 합병증으로 발병할 확률이 높습니다.'
	elif result==0:
		comment='당뇨병콩밭병증이 합병증으로 발병할 확률이 낮습니다.'
	
	return render_template('analysis_one.html',data=comment)


#-------------------------------------------------------------------------------------
#웹페이지에서 업로드한 파일 파이썬으로 가져오기 
@app.route('/file_upload', methods=['POST', 'GET'])
def file_upload():
    if request.method =='POST':
        f = request.files['file']
        if f.filename == '':
            tk=Tk()
            tk.wm_attributes("-topmost",1)
            tk.withdraw()
            messagebox.showerror("경고","업로드된 파일이 없습니다. 파일을 업로드 해주십시오.") 
            tk.destroy()
            return render_template('predict_page.html')
        f.save('./uploads/' + secure_filename(f.filename))


        try:
            df=pd.read_csv('./uploads/' + f.filename)
        except pd.errors.EmptyDataError:
            tk=Tk()
            tk.wm_attributes("-topmost",1)
            tk.withdraw()
            messagebox.showerror("경고","파일이 비어있습니다. 다시 업로드 해주십시오.") 
            tk.destroy()
            return render_template('predict_page.html')
        upload_file=pd.read_csv('./uploads/' + secure_filename(f.filename))
        if (not 'ACR' in list(upload_file.columns)) or (not 'POG30' in list(upload_file.columns)) or (not 'ISL25P75P_I' in list(upload_file.columns)) or (not 'RPGN2' in list(upload_file.columns)) or (not 'ISGG_I' in list(upload_file.columns)):
            tk=Tk()
            tk.wm_attributes("-topmost",1)
            tk.withdraw()
            messagebox.showerror("경고","지정된 파일 형식이 아닙니다. 다시 한 번 확인하십시오.") 
            tk.destroy()
            return render_template('predict_page.html')


        result=XGBoost_two_over(f.filename)	

        return render_template('analysis_two.php',data=result.to_html(index=False))

    else:
        return render_template('analysis_one.html')

#-------------------------------------------------------------------------------------
# 튜토리얼 페이지 
@app.route('/tutorial')
def tutorial_page():
	return render_template('tutorial_page.html')
# 정보 페이지 
@app.route('/information')
def information_page():
	return render_template('information_page.html')
# 예측 페이지 
@app.route('/predict')
def midas_analysis():
	return render_template('predict_page.html')
# 멤버 페이지 
@app.route('/member')
def member_page():
	return render_template('member_info.html')
# 메인 페이지 
@app.route('/')
def midas_home():
	return render_template('main.html')

# 플라스크 서버 실행 
if __name__ == '__main__':
    # app.run(host='0.0.0.0', port=8080, debug=True)
	app.run(debug=True)

